<nav>
	<ul>
		<li><a href="index.php?action=alumnos">Alumnos</a></li>
		<!-- Pra navegar al URL podemos hacerlo mediante la variable GET, la cual la toma del URL, se representa por el simbolo "?"-->
		<li><a href="index.php?action=carreras">Carreras</a></li>
		<li><a href="index.php?action=maestros">Maestros</a></li>
		<li><a href="index.php?action=productos">Tutorias</a></li>
		<li><a href="index.php?action=salir">Salir</a></li>
	</ul>
</nav>