<nav style="font-family: Arial;">
	<ul>
		<li><a href="index.php">Inicio</a></li>
		<!-- Pra navegar al URL podemos hacerlo mediante la variable GET, la cual la toma del URL, se representa por el simbolo "?"-->
		<li><a href="index.php?action=alumnos">Alumnos</a></li>
		<li><a href="index.php?action=carreras">Carreras</a></li>
		<!--li><a href="index.php?action=productos">Productos</a></li-->
		<li><a href="index.php?action=maestros">Maestros</a></li>
		<li><a href="index.php?action=tutorias">Tutorias</a></li>
		<li><a href="index.php?action=salir">Reportes</a></li>
		<li><a href="index.php?action=salir">Salir</a></li>
	</ul>
</nav>