<!DOCTYPE html>
<html>
<head>
	<title>INICIO</title>
</head>
<body>

	<center>
	<h1>HOLA BIENVENIDO!</h1>
	<h3>PUEDES NAVEGAR POR EL MENU DE ARRIBA</h3>
	</center>

</body>
</html>