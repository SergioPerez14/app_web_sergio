<?php
	//Las credenciales para conectarse a la base de datos usando PDO
	$dsn = 'mysql:dbname=php_sql_course;host=localhost';
	$user = 'root';
	$password = '';
?>