<?php
  //Credenciales para la conexion a la base de datos
  $servidor = 'localhost';
  $usuario = 'root';
  $password = '';
  $bd = 'usuarios';
?>