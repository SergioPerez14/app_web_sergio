<nav>
	<ul>
		<li><a href="index.php">CONVERTIDOR Y CODIFICADOR DE CODIGOS EN LINEA</a></li>
		<!-- Pra navegar al URL podemos hacerlo mediante la variable GET, la cual la toma del URL, se representa por el simbolo "?"-->
	</ul>
</nav>