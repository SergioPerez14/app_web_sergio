<?php
header("Location: listar.php");
?>